#define DRIVERVERSION	"v4.1.7_7825.20130613_beta_auto_ra"
