1. Overview

This is the release of Broadcom Android 2.3 WAPI and WPS project, which is
based on android-2.3.3_r1 branch.

The release package includes the followings,
- android_cm_changes: Android 2.3 GUI changes for WAPI and WPS settings.
- wapilib: WAPI core library source code for Android.
- wpa_supplicant_6: Modified supplicant based on wpa_supplicant_6 in 2.3.
- patches: diff files for patch use if preferred.

2. Android GUI changes

android_cm_changes folder contains the modified files for adding WAPI security
settings and WPS network in Android 2.3 (Gingerbread) GUI.  The changes should
be merged to Android source tree.

Please check out readme-android-cm-changes.txt for detail.

3. WAPI core library

The source code should be copied to Android source tree under external
directory.  To build the project, please merge the build file in
android_cm_changes and follow the normal Android build procedure.

cp -rf wapilib <ANDROID_ROOT>/external/wapilib

4. WAPI and WPS changes for wpa supplicant

There are two wpa supplicant external projects in Android 2.3.  One is
wpa_supplicant based on 0.5.11, another is wpa_supplicant_6 based on 0.6.10.
The changes are for wpa_supplicant_6.

In Android 2.3 source tree, there should already be a wpa_supplicant_6 external
project.  Please backup and remove the original wpa_supplicant_6 directory
before copying.  Otherwise, it will overwrite the original source code.  Please
make sure the directories are copied to the correct location before build.

mv <ANDROID_ROOT>/external/wpa_supplicant_6 ./wpa_supplicant_6.orig
cp -rf wpa_supplicant_6 <ANDROID_ROOT>/external/wpa_supplicant_6

On the other hand, if you prefer to apply patch over the original
wpa_supplicant_6, the patch file is also included.

cp wpa_supplicant_6-wapi-wps.patch <ANDROID_ROOT>/external/wpa_supplicant_6
cd <ANDROID_ROOT>/external/wpa_supplicant_6
cat wpa_supplicant_6-wapi-wps.patch | patch -p1

Please note, in order to build correct wpa_supplicant version,
WPA_SUPPLICANT_VERSION := VER_0_6_X should be defined in board specific
makefile.

5. Firmware and driver

WAPI need wapi-support firmware, please replace android2.3_root/external/wlan_loader/firmware/fw_bcm4329 
with ./firmware/fw_bcm4329.bin.   

The firmware binary and DHD driver should also built with WAPI support.  Please
contact the support if there is any question.

