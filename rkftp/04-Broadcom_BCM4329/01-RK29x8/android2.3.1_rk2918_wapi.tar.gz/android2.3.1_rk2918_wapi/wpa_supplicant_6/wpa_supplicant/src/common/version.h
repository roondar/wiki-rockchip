#ifndef VERSION_H
#define VERSION_H

#define VERSION_STR "0.6.10-2.02 (Powered by Rockchip)"

#endif /* VERSION_H */
