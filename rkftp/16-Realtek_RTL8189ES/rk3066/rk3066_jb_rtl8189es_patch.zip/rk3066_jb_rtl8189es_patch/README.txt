补丁使用说明：

【1】android部分：

	1、根据wifi.c.patch、CommandListen.cpp.patch、device.mk.patch分别打上对应的补丁文件。

	2、将8189es.ko文件复制到android/device/rockchip/rk2928sdk目录下。

【2】kernel部分：

	1、根据Kconfig.patch、rkwifi_config.c.patch分别打上内核对应的补丁文件。

	2、将rtl8189es.tgz解压到目录kernel/drivers/net/wireless目录下。

	3、make menuconfig选择8189ES的配置项。

重新编译kernel和android。

注：8189es.ko引用board.c文件的wifi power control函数。所以需要在board-rk2928-sdk-sdmmc.c
文件中修改成对应的power控制gpio口。

